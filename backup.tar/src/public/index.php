<?php

require __DIR__ . "/../bootstrap/app.php";

$app->run();
