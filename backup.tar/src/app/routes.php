<?php
$app->get('/', function() {
	return 'Home';
});

